package com.garden.loader;

import files.FilePath;
import files.FilePathWriter;
import org.springframework.stereotype.Component;
import java.io.IOException;
import java.util.Locale;

@Component
public final class MakeExecute {
    public void execute(String... args) {
        if (args == null || args.length == 0) {
            throw new IllegalArgumentException("No se especificó ningún comando.");
        }
        String command = args[0].toLowerCase(Locale.ROOT);
        switch (command) {
            case "make:model" -> {
                requireArgumentCount(args, 2);
                makeModel(requireClassName(args[1]));
            }
            case "make:controller" -> {
                requireArgumentCount(args, 2);
                makeController(requireClassName(args[1]));
            }
            case "make:service" -> {
                requireArgumentCount(args, 2);
                makeService(requireClassName(args[1]));
            }
            case "make:dao" -> {
                requireArgumentCount(args, 2);
                makeDao(requireClassName(args[1]));
            }
            case "make:seeder" -> {
                requireArgumentCount(args, 2);
                makeSeeder(requireClassName(args[1]));
            }
            case "make:dto" -> {
                requireArgumentCount(args, 3);
                String type = args[1].toLowerCase(Locale.ROOT);
                if (!type.equals("request") && !type.equals("response")) {
                    throw new IllegalArgumentException(
                            "El tipo de DTO debe ser 'request' o 'response'."
                    );
                }
                makeDto(type, requireClassName(args[2]));
            }

            case "make:migration" -> {
                requireArgumentCount(args, 3);
                String migrationName = requireClassName(args[1]);
                long version;
                try {
                    version = Long.parseLong(args[2]);
                } catch (NumberFormatException e) {
                    throw new IllegalArgumentException(
                            "La versión de la migration debe ser un número entero.",
                            e
                    );
                }
                if (version <= 0) {
                    throw new IllegalArgumentException(
                            "La versión de la migration debe ser mayor que cero."
                    );
                }
                makeMigration(migrationName, version);
            }

            case "make:view" ->{
                requireArgumentCount(args, 2);
                makeView(args[1]);
            }

            case "make:html" ->{
                requireArgumentCount(args, 2);
                makeHtmlView(args[1]);
            }

            case "make:html-path"->{
                requireArgumentCount(args, 3);
                makeHtmlView(args[1],args[2]);
            }
            default -> throw new IllegalArgumentException(
                    "Comando desconocido: " + args[0]
            );
        }
    }

    private void requireArgumentCount(String[] args, int expected) {
        if (args.length != expected) {
            throw new IllegalArgumentException(
                    "Cantidad incorrecta de argumentos para: " + args[0]
            );
        }
    }

    private String requireClassName(String name) {
        if (name == null || !name.matches("[A-Za-z_$][A-Za-z0-9_$]*")) {
            throw new IllegalArgumentException(
                    "Nombre de clase Java inválido: " + name
            );
        }

        return name;
    }

    private void makeSeeder(String seederName){
        FilePath filePath = new FilePath("src/main/java/com/garden/database/seeders/" + seederName + ".java");
        if (!filePath.exists()) {
            try {
                if (!filePath.createFile()) {
                    throw new RuntimeException(
                            "Could not create seeder " + seederName
                    );
                }
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }else{
            System.out.println("Garden: El seeder ya existe!");
            return;
        }

        try(FilePathWriter filePathWriter = new FilePathWriter(filePath)) {
            filePathWriter.write(
                    "package com.garden.database.seeders;\n" +
                            "\n" +
                            "import com.garden.utils.Seeder;\n" +
                            "import org.springframework.stereotype.Component;\n" +
                            "\n" +
                            "@Component\n" +
                            "public class "+seederName+" extends Seeder{\n" +
                            "    @Override\n" +
                            "    public void run() {\n" +
                            "        cmd.insert(\n" +
                            "                \"command sql\",\n" +
                            "                \"value1\", \"value2\",\"value3\"\n" +
                            "        );\n" +
                            "    }\n" +
                            "}"
            );
            System.out.println("----------------------------");
            System.out.println("Seeder created successfully!");
            System.out.println("----------------------------");
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private void makeMigration(String migrationName,long version){
        FilePath filePath = new FilePath("src/main/java/com/garden/database/migrations/" + migrationName + ".java");
        if (!filePath.exists()) {
            try {
                if (!filePath.createFile()) {
                    throw new RuntimeException(
                            "Could not create migration " + migrationName
                    );
                }
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }else{
            System.out.println("Garden: La migration ya existe!");
            return;
        }

        try(FilePathWriter filePathWriter = new FilePathWriter(filePath)) {
            filePathWriter.write(
                    "package com.garden.database.migrations;\n" +
                            "\n" +
                            "import com.glass.migrations.Migration;\n" +
                            "import com.glass.migrations.Schema;\n" +
                            "import org.springframework.stereotype.Component;\n" +
                            "\n" +
                            "@Component\n" +
                            "public final class "+migrationName+" extends Migration {\n" +
                            "\n" +
                            "    @Override\n" +
                            "    public void up() {\n" +
                            "        Schema.createIfNotExists(\"name\", table -> {\n" +
                            "            table.id(\"id\");\n" +
                            "            table.string(\"name\");\n" +
                            "            table.timestamps();\n" +
                            "        });\n" +
                            "    }\n" +
                            "\n" +
                            "    @Override\n" +
                            "    public void down() {\n" +
                            "        Schema.dropIfExists(\"name\");\n" +
                            "    }\n" +
                            "\n" +
                            "    @Override\n" +
                            "    public String description() {\n" +
                            "        return \"Created table\";\n" +
                            "    }\n" +
                            "\n" +
                            "    @Override\n" +
                            "    public long version() {\n" +
                            "        return " + version + "L;\n" +
                            "    }\n" +
                            "}"
            );
            System.out.println("-------------------------------");
            System.out.println("Migration created successfully!");
            System.out.println("-------------------------------");
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private void makeService(String serviceName){
        FilePath filePath = new FilePath("src/main/java/com/garden/app/services/" + serviceName + ".java");
        if (!filePath.exists()) {
            try {
                if (!filePath.createFile()) {
                    throw new RuntimeException(
                            "Could not create service " + serviceName
                    );
                }
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }else{
            System.out.println("Garden: El servicio ya existe!");
            return;
        }

        try(FilePathWriter filePathWriter = new FilePathWriter(filePath)) {
            filePathWriter.write(
                    "package com.garden.app.services;\n" +
                            "\n" +
                            "import com.garden.utils.service.Service;\n" +
                            "\n" +
                            "@org.springframework.stereotype.Service\n" +
                            "public class "+serviceName+" implements Service {\n" +
                            "\n" +
                            "    @Override\n" +
                            "    public void init() {\n" +
                            "\n" +
                            "    }\n" +
                            "\n" +
                            "    @Override\n" +
                            "    public Object execute() {\n" +
                            "        return Service.super.execute();\n" +
                            "    }\n" +
                            "}"
            );

            System.out.println("-----------------------------");
            System.out.println("Service created successfully!");
            System.out.println("-----------------------------");
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private void makeController(String controllerName){
        FilePath filePath = new FilePath("src/main/java/com/garden/app/controllers/" + controllerName + ".java");
        if (!filePath.exists()) {
            try {
                if (!filePath.createFile()) {
                    throw new RuntimeException(
                            "Could not create controller " + controllerName
                    );
                }
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }else{
            System.out.println("Garden: El controlador ya existe!");
            return;
        }

        try(FilePathWriter filePathWriter = new FilePathWriter(filePath)) {
            filePathWriter.write(
                    "package com.garden.app.controllers;\n" +
                            "\n" +
                            "import com.garden.utils.controller.Controller;\n" +
                            "import org.springframework.web.bind.annotation.GetMapping;\n" +
                            "import org.springframework.web.bind.annotation.RequestMapping;\n" +
                            "import org.springframework.web.bind.annotation.ResponseBody;\n" +
                            "\n" +
                            "@org.springframework.stereotype.Controller\n" +
                            "@RequestMapping(\"/\")\n" +
                            "public class "+controllerName+" extends Controller {\n" +
                            "    @GetMapping(\"/index\")\n" +
                            "    @ResponseBody\n" +
                            "    public String index() {\n" +
                            "        return \"Hello World\";\n" +
                            "    }\n" +
                            "}"
            );
            System.out.println("--------------------------------");
            System.out.println("Controller created successfully!");
            System.out.println("--------------------------------");
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private void makeDto(String type,String dtoName){
        FilePath filePath = new FilePath("src/main/java/com/garden/app/dto/" + type + "/" + dtoName + ".java");
        if (!filePath.exists()) {
            try {
                if (!filePath.createFile()) {
                    throw new RuntimeException(
                            "Could not create " + type + "dto " + dtoName
                    );
                }
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }

        try(FilePathWriter filePathWriter = new FilePathWriter(filePath)) {
            if(type.equals("request")){
                filePathWriter.write(
                        "package com.garden.app.dto.request;\n" +
                                "\n" +
                                "import com.glass.data.Model;\n" +
                                "import database.object.DtoRequest;\n" +
                                "import java.util.Map;\n" +
                                "\n" +
                                "public record "+dtoName+"() implements DtoRequest<Model,"+dtoName+"> {\n" +
                                "    @Override\n" +
                                "    public Model toModel("+dtoName+" request) {\n" +
                                "        return null;\n" +
                                "    }\n" +
                                "\n" +
                                "    @Override\n" +
                                "    public "+dtoName+" fromData(Map<String, Object> map) {\n" +
                                "        return null;\n" +
                                "    }\n" +
                                "}"
                );

                System.out.println("---------------------------------");
                System.out.println("DTO Request created successfully!");
                System.out.println("---------------------------------");
            }else if(type.equals("response")){
                filePathWriter.write(
                        "package com.garden.app.dto.response;\n" +
                                "\n" +
                                "import com.glass.data.Model;\n" +
                                "import database.object.DtoResponse;\n" +
                                "import java.util.Map;\n" +
                                "\n" +
                                "public record "+dtoName+"() implements DtoResponse<Model, "+dtoName+"> {\n" +
                                "    @Override\n" +
                                "    public "+dtoName+" toDto(Model model) {\n" +
                                "        return null;\n" +
                                "    }\n" +
                                "\n" +
                                "    @Override\n" +
                                "    public Map<String, Object> toData("+dtoName+" response) {\n" +
                                "        return Map.of();\n" +
                                "    }\n" +
                                "}"
                );

                System.out.println("----------------------------------");
                System.out.println("DTO Response created successfully!");
                System.out.println("----------------------------------");
            }else{
                throw new IllegalArgumentException("Type invalid");
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private void makeDao(String daoName){
        FilePath filePath = new FilePath("src/main/java/com/garden/app/repositories/" + daoName + ".java");
        if (!filePath.exists()) {
            try {
                if (!filePath.createFile()) {
                    throw new RuntimeException(
                            "Could not create dao for persistence " + daoName
                    );
                }
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }else{
            System.out.println("Garden: El dao ya existe!");
            return;
        }

        try(FilePathWriter filePathWriter = new FilePathWriter(filePath)) {
            filePathWriter.write(
                    "package com.garden.app.repositories;\n" +
                            "\n" +
                            "import com.glass.data.EntityDao;\n" +
                            "import com.glass.data.Model;\n" +
                            "import org.springframework.stereotype.Repository;\n" +
                            "\n" +
                            "@Repository\n" +
                            "public class "+daoName+" extends EntityDao<Model,Object>{\n" +
                            "    public "+daoName+"(){\n" +
                            "        super(Model.class);\n" +
                            "    }\n" +
                            "}"
            );
            System.out.println("-------------------------");
            System.out.println("Dao created successfully!");
            System.out.println("-------------------------");
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private void makeProvider(String providerName){
        FilePath filePath = new FilePath("src/main/java/com/garden/app/providers/" + providerName + ".java");
        if (!filePath.exists()) {
            try {
                if (!filePath.createFile()) {
                    throw new RuntimeException(
                            "Could not create provider " + providerName
                    );
                }
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }else{
            System.out.println("Garden: El provider ya existe!");
            return;
        }

        try(FilePathWriter filePathWriter = new FilePathWriter(filePath)) {
            filePathWriter.write(
                    "package com.garden.app.providers;\n" +
                            "\n" +
                            "import com.garden.utils.providers.ServiceContainer;\n" +
                            "import com.garden.utils.providers.ServiceProvider;\n" +
                            "import org.springframework.stereotype.Component;\n" +
                            "\n" +
                            "@Component\n" +
                            "public class "+providerName+" implements ServiceProvider {\n" +
                            "    @Override\n" +
                            "    public void register(ServiceContainer container) {\n" +
                            "\n" +
                            "    }\n" +
                            "\n" +
                            "    @Override\n" +
                            "    public void boot(ServiceContainer container) {\n" +
                            "        ServiceProvider.super.boot(container);\n" +
                            "    }\n" +
                            "\n" +
                            "    @Override\n" +
                            "    public void shutdown(ServiceContainer container) {\n" +
                            "        ServiceProvider.super.shutdown(container);\n" +
                            "    }\n" +
                            "}"
            );
            System.out.println("---------------------------");
            System.out.println("Provider created successfully!");
            System.out.println("---------------------------");
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private void makeModel(String className){
        FilePath filePath = new FilePath("src/main/java/com/garden/app/models/" + className + ".java");
        if (!filePath.exists()) {
            try {
                if (!filePath.createFile()) {
                    throw new RuntimeException(
                            "Could not create model for persistence " + className
                    );
                }
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }else{
            System.out.println("Garden: El modelo ya existe!");
            return;
        }

        try(FilePathWriter filePathWriter = new FilePathWriter(filePath)) {
            filePathWriter.write(
                    "package com.garden.app.models;\n" +
                            "\n" +
                            "import com.glass.data.Model;\n" +
                            "import com.glass.annotations.Entity;\n" +
                            "\n" +
                            "@Entity(tableName = \"name\")\n" +
                            "public class " + className + " extends Model{\n"+
                            "}"
            );
            System.out.println("---------------------------");
            System.out.println("Model created successfully!");
            System.out.println("---------------------------");
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private void makeView(String viewName){
        FilePath filePathView = new FilePath("src/main/java/com/garden/app/views/view/" + viewName + ".java");
        FilePath filePathProvider = new FilePath("src/main/java/com/garden/app/views/providers/" + viewName + "Provider.java");
        if (!filePathView.exists() && !filePathProvider.exists()) {
            try {
                if (!filePathView.createFile() && !filePathProvider.createFile()) {
                    throw new RuntimeException(
                            "Could not create view " + viewName
                    );
                }
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }else{
            System.out.println("Garden: La vista ya existe!");
            return;
        }

        try(FilePathWriter filePathWriter = new FilePathWriter(filePathView)) {
            filePathWriter.write(
                    "package com.garden.app.views.view;\n" +
                            "\n" +
                            "import com.garden.annotations.View;\n" +
                            "import com.garden.views.GardenView;\n" +
                            "import frames.Frame;\n" +
                            "import layout.FlexDirection;\n" +
                            "import layout.LayoutType;\n" +
                            "\n" +
                            "@View(name = \""+viewName+"\",title = \"View\")\n" +
                            "public class "+viewName+" extends Frame implements GardenView{\n" +
                            "    public "+viewName+"() {\n" +
                            "        this.title(\"Garden View\");\n" +
                            "        this.layout.type(LayoutType.FLEX).direction(FlexDirection.COLUMN);\n" +
                            "    }\n" +
                            "\n" +
                            "}"
            );
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        try(FilePathWriter filePathWriter = new FilePathWriter(filePathProvider)) {
            filePathWriter.write(
                    "package com.garden.app.views.providers;\n" +
                            "\n" +
                            "import com.garden.app.views.view."+viewName+";\n" +
                            "import com.garden.views.GardenViewProvider;\n" +
                            "import org.springframework.stereotype.Component;\n" +
                            "\n" +
                            "@Component\n" +
                            "public class "+viewName+"Provider implements GardenViewProvider<"+viewName+">{\n" +
                            "    @Override\n" +
                            "    public "+viewName+" createView() {\n" +
                            "        return new "+viewName+"();\n" +
                            "    }\n" +
                            "}"
            );
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        System.out.println("---------------------------");
        System.out.println("View created successfully!");
        System.out.println("---------------------------");
    }

    private void makeHtmlView(String htmlName){
        makeHtmlView("",htmlName);
    }

    private void makeHtmlView(String path,String htmlName){
        if(!path.isEmpty() && !path.endsWith("/")){
            path = path + "/";
        }

        FilePath filePath = new FilePath("src/main/resources/views/" + path + htmlName + ".html");
        if (!filePath.exists()) {
            try {
                if (!filePath.createFile()) {
                    throw new RuntimeException(
                            "Could not create view html" + htmlName
                    );
                }
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }else{
            System.out.println("Garden:La vista HTML ya existe!");
            return;
        }

        try(FilePathWriter filePathWriter = new FilePathWriter(filePath)) {
            filePathWriter.write(
                    "<!DOCTYPE html>\n" +
                            "<html lang=\"en\" xmlns:th=\"http://www.thymeleaf.org\">\n" +
                            "<head>\n" +
                            "    <meta charset='utf-8'>\n" +
                            "    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n" +
                            "    <title>Document</title>\n" +
                            "</head>\n" +
                            "<body>\n" +
                            "</body>\n" +
                            "</html>"
            );
            System.out.println("---------------------------");
            System.out.println("View HTML created successfully!");
            System.out.println("---------------------------");
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}