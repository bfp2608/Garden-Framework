package com.garden.app.repositories;

import com.garden.app.models.User;
import com.glass.data.EntityDao;
import org.springframework.stereotype.Repository;

@Repository
public class UserDao extends EntityDao<User,Long>{
    public UserDao(){
        super(User.class);
    }
}