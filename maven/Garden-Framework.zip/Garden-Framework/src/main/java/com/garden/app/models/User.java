package com.garden.app.models;

import com.garden.app.repositories.UserDao;
import com.garden.utils.AuthModel;
import com.glass.annotations.Column;
import com.glass.annotations.Entity;
import com.glass.annotations.PrimaryKey;
import java.time.LocalDateTime;

@Entity(tableName = "users")
public class User extends AuthModel{
    @PrimaryKey(name = "user_id")
    private long id;

    @Column(name = "name",unique = true)
    private String name;

    @Column(name = "password",nullable = false)
    private String password;

    @Column(name = "email",nullable = false,unique = true)
    private String email;

    @Column(name = "email_verify_at")
    private LocalDateTime emailVerifyAt;

    @Override
    public UserDao dao() {
        return new UserDao();
    }
}