package com.garden.cli;

import com.garden.loader.MakeExecute;

public final class MakeMain {

    private MakeMain() {
    }

    public static void main(String[] args) {
        if (args == null || args.length == 0) {
            printUsage();
            return;
        }

        try {
            MakeExecute makeExecute = new MakeExecute();
            makeExecute.execute(args);
        } catch (Exception e) {
            System.err.println("Garden Make: " + e.getMessage());
            throw new RuntimeException(e);
        }
    }

    private static void printUsage() {
        System.out.println("""
                Garden Make

                Commands:
                  make:model <name>
                  make:controller <name>
                  make:service <name>
                  make:dao <name>
                  make:seeder <name>
                  make:dto <request|response> <name>
                  make:migration <name> <version>
                  make:view <name>
                  make:html <name>
                  make:html-path <path> <name>

                Examples:
                  make:model Usuario
                  make:controller UsuarioController
                  make:dto request UsuarioRequest
                  make:dto response UsuarioResponse
                  make:migration CreateUsersTable 1001
                  make:view UsuariosView
                  make:html index-usuarios
                  make:html-path /site/usuarios/ create-usuarios
                """);
    }
}