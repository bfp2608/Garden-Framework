package com.garden;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GardenFrameworkApplicationTests {

	@Test
	void contextLoads() {
	}

}
