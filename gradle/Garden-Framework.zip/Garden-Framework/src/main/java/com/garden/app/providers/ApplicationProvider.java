package com.garden.app.providers;

import com.garden.utils.providers.ServiceContainer;
import com.garden.utils.providers.ServiceProvider;
import org.springframework.stereotype.Component;

@Component
public class ApplicationProvider implements ServiceProvider {
    @Override
    public void register(ServiceContainer container) {

    }

    @Override
    public void boot(ServiceContainer container) {
        ServiceProvider.super.boot(container);
    }

    @Override
    public void shutdown(ServiceContainer container) {
        ServiceProvider.super.shutdown(container);
    }
}