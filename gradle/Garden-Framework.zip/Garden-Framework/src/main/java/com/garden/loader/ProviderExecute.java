package com.garden.loader;

import com.garden.utils.providers.ServiceContainer;
import com.garden.utils.providers.ServiceProvider;
import org.springframework.stereotype.Component;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

@Component
public final class ProviderExecute {
    private final ServiceContainer container;
    private final List<ServiceProvider> providers;
    private boolean registered;
    private boolean initialized;

    public ProviderExecute(
            ServiceContainer container,
            List<ServiceProvider> providers
    ) {
        this.container = container;
        List<ServiceProvider> ordered = new ArrayList<>(providers);
        ordered.sort(Comparator.comparingInt(
                ServiceProvider::getOrder
        ));
        this.providers = List.copyOf(ordered);
    }

    public void execute(String command) {
        if (command == null || command.isBlank()) {
            return;
        }
        switch (command.trim().toLowerCase(Locale.ROOT)) {
            case "register" -> register();
            case "boot" -> boot();
            case "execute" -> execute();
            case "none" -> System.out.println("Provider execution skipped");
            default -> throw new IllegalArgumentException(
                    "Comando no reconocido: " + command
            );
        }
    }

    public void register() {
        if (registered) {
            return;
        }
        for (ServiceProvider provider : providers) {
            provider.register(container);
        }

        registered = true;
    }

    public void boot() {
        if (initialized) {
            return;
        }
        register();
        for (ServiceProvider provider : providers) {
            provider.boot(container);
        }
        initialized = true;
    }

    public void execute() {
        register();
        boot();
    }

    public void shutdown() {
        if (!initialized) {
            return;
        }
        for (int i = providers.size() - 1; i >= 0; i--) {
            providers.get(i).shutdown(container);
        }
        initialized = false;
    }
}