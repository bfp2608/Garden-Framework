package com.garden.app.views.providers;

import com.garden.app.views.view.MainView;
import com.garden.views.GardenViewProvider;
import org.springframework.stereotype.Component;

@Component
public class MainViewProvider implements GardenViewProvider<MainView>{
    @Override
    public MainView createView() {
        return new MainView();
    }
}