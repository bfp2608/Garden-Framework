package com.garden.app.services;

import com.garden.app.repository.UserDao;
import com.garden.utils.service.Service;
import com.gum.org.security.PassHash;

@org.springframework.stereotype.Service
public class UserService implements Service {
    private final UserDao userDao;
    private final PassHash hash;

    public UserService(UserDao userDao, PassHash hash) {
        this.userDao = userDao;
        this.hash = hash;
    }

    @Override
    public void init() {

    }

    @Override
    public Object execute() {
        return Service.super.execute();
    }
}