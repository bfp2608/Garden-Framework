package com.garden.cli;

import com.garden.Application;
import com.garden.loader.SeederExecute;
import org.springframework.boot.WebApplicationType;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.ConfigurableApplicationContext;

public final class SeederMain {
    public static void main(String[] args) {
        try (ConfigurableApplicationContext context =
                     new SpringApplicationBuilder(Application.class)
                             .web(WebApplicationType.NONE)
                             .run()) {

            SeederExecute seeder =
                    context.getBean(SeederExecute.class);

            String command = args.length == 0
                    ? "none"
                    : String.join(" ", args);

            seeder.execute(command);
        }
    }
}