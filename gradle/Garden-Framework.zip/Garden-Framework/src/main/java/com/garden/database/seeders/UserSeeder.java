package com.garden.database.seeders;

import com.garden.utils.Seeder;
import org.springframework.stereotype.Component;

@Component
public class UserSeeder extends Seeder{
    @Override
    public void run() {
        cmd.insert(
                "insert into user(name,password,email) values(?,?,?)",
                "user_first1", "admHashable","example@example"
        );
    }
}