package com.garden.cli;

import com.garden.Application;
import com.garden.loader.MigrationExecute;
import org.springframework.boot.WebApplicationType;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.ConfigurableApplicationContext;

public final class MigrationMain {
    public static void main(String[] args) {
        try (ConfigurableApplicationContext context =
                     new SpringApplicationBuilder(Application.class)
                             .web(WebApplicationType.NONE)
                             .run()) {

            MigrationExecute migration =
                    context.getBean(MigrationExecute.class);

            String command = args.length == 0
                    ? "none"
                    : String.join(" ", args);

            migration.execute(command);
        }
    }
}
