package com.garden.cli;

import com.garden.config.GardenDesktop;
import com.garden.loader.ViewExecute;
import org.springframework.boot.WebApplicationType;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.ConfigurableApplicationContext;

public final class ViewMain {

    public static void main(String[] args) {
        ConfigurableApplicationContext context =
                new SpringApplicationBuilder(GardenDesktop.class)
                        .web(WebApplicationType.NONE)
                        .headless(false)
                        .run(args);
        context.getBean(ViewExecute.class).execute();
    }
}