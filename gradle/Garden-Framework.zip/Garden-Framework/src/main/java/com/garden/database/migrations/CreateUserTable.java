package com.garden.database.migrations;

import com.glass.migrations.Migration;
import com.glass.migrations.Schema;
import org.springframework.stereotype.Component;

@Component
public final class CreateUserTable extends Migration {

    @Override
    public void up() {
        Schema.createIfNotExists("users", table -> {
            table.id("user_id");
            table.string("name").notNull().unique();
            table.string("email").unique();
            table.timestamp("email_verified_at").nullable();
            table.string("password").notNull();
            table.timestamps();
        });
    }

    @Override
    public void down() {
        Schema.dropIfExists("users");
    }

    @Override
    public String description() {
        return "Creación de tabla de prueba de usuarios";
    }

    @Override
    public long version() {
        return 1;
    }
}