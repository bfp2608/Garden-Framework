package com.garden.loader;

import com.garden.utils.Seeder;
import org.springframework.stereotype.Component;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

@Component
public final class SeederExecute {
    private final List<Seeder> seeders;

    public SeederExecute(List<Seeder> seeders) {
        validateSeeders(seeders);
        this.seeders = List.copyOf(seeders);
    }

    public void execute(String commandLine) {
        if (commandLine == null || commandLine.isBlank()) {
            return;
        }

        String[] command = commandLine.trim().split("\\s+", 2);

        switch (command[0].toLowerCase(Locale.ROOT)) {
            case "run" -> {
                if (command.length > 1) {
                    run(command[1].trim());
                } else {
                    run();
                }
            }

            case "none" -> System.out.println(
                    "Seeder execution skipped"
            );

            default -> throw new IllegalArgumentException(
                    "Comando no reconocido: " + command[0]
            );
        }
    }

    public void run() {
        for (Seeder seeder : seeders) {
            executeSeeder(seeder);
        }
    }

    public void run(String name) {
        Seeder seeder = findSeeder(name);

        if (seeder == null) {
            throw new IllegalArgumentException(
                    "No se encontró el seeder: " + name
            );
        }

        executeSeeder(seeder);
    }

    private void executeSeeder(Seeder seeder) {
        String name = seeder.name();

        try {
            System.out.println("Ejecutando seeder: " + name);

            seeder.run();

            System.out.println(
                    "Seeder ejecutado correctamente: " + name
            );

        } catch (Exception e) {
            throw new IllegalStateException(
                    "Error ejecutando el seeder: " + name,
                    e
            );
        }
    }

    private Seeder findSeeder(String name) {
        return seeders.stream()
                .filter(seeder ->
                        seeder.name().equalsIgnoreCase(name)
                )
                .findFirst()
                .orElse(null);
    }

    private void validateSeeders(List<Seeder> seeders) {
        Set<String> names = new HashSet<>();

        for (Seeder seeder : seeders) {
            if (seeder == null) {
                throw new IllegalStateException(
                        "La lista contiene un seeder nulo"
                );
            }

            String name = seeder.name();

            if (name == null || name.isBlank()) {
                throw new IllegalStateException(
                        "El nombre del seeder no puede estar vacío"
                );
            }

            if (!names.add(name.toLowerCase(Locale.ROOT))) {
                throw new IllegalStateException(
                        "Seeder duplicado: " + name
                );
            }
        }
    }
}