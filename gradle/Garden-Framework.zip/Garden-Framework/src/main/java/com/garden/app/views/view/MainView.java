package com.garden.app.views.view;

import com.garden.annotations.View;
import com.garden.views.GardenView;
import controls.basic.Text;
import controls.basic.Title;
import frames.Frame;
import layout.FlexDirection;
import layout.LayoutType;
import style.WindowPosition;
import java.awt.*;

@View(name = "index",title = "Garden Framework",main = true,html = true)
public class MainView extends Frame implements GardenView{
    public MainView() {
        this.style
                .size(500,700)
                .titleBarBackground(Color.BLUE)
                .titleBarColor(Color.WHITE)
                .position(WindowPosition.MIDDLE_CENTER)
        ;
        this.layout.type(LayoutType.FLEX).direction(FlexDirection.COLUMN);
        this.title = new Title("Garden Framework");
        this.txtInfo = new Text("¡Bienvenido a garden framework!");
        this.add(title).add(txtInfo);
    }

    private final Title title;
    private final Text txtInfo;
}