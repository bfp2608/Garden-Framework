
package com.garden.config;

import com.garden.utils.AuthModel;
import com.gum.org.token.GeneratedToken;
import com.gum.org.token.Token;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.util.Map;

@Service
public final class AuthManager {
    private final Token token;

    public AuthManager(Token token) {
        this.token = token;
    }

    public Token token() {
        return token;
    }

    public GeneratedToken generate(AuthModel user, Duration expiration) {
        return token.generateToken(
                String.valueOf(user.pkValue()),
                Map.of(),
                expiration
        );
    }
}