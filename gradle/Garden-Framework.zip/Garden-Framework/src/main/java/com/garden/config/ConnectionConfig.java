package com.garden.config;

import com.glass.database.connection.*;
import com.glass.database.loggers.SqlLogger;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public final class ConnectionConfig {
    @Value("${garden.connection.motor}")
    private String motor;

    @Value("${garden.connection.username}")
    private String username;

    @Value("${garden.connection.password}")
    private String password;

    @Value("${garden.connection.url.server:localhost}")
    private String server;

    @Value("${garden.connection.url.port:3306}")
    private int port;

    @Value("${garden.connection.url.database}")
    private String database;

    @Value("${garden.connection.url.encrypt:false}")
    private boolean encrypt;

    @Value("${garden.connection.url.trustCertification:false}")
    private boolean trustCertification;

    @PostConstruct
    public void initialize() {
        DatabaseConnection dbConnection = connection();
        dbConnection.save();
        SqlLogger.setShowSql(true);
    }

    public DatabaseConnection connection() {
        return switch (motor) {
            case "MySql" -> new MySqlConnection(
                    server, database, port, username, password
            );

            case "SqlServer" -> new SqlServerConnection(
                    server, database, port, encrypt,
                    trustCertification, username, password
            );

            case "PostgreSql" -> new PostgresSqlConnection(
                    server, port, database, username, password
            );

            case "Oracle" -> new OracleSqlConnection(
                    server, port, database, username, password
            );

            case "SqlLite" -> new SqlLiteConnection(
                    database,username,password
            );

            case "MariaDB" -> new MariaDBConnection(
                    server,database,port,username,password
            );

            default -> throw new IllegalArgumentException(
                    "¡Motor inválido: " + motor + "!"
            );
        };
    }
}