package com.garden.config;

import com.garden.utils.providers.ServiceContainer;
import com.gum.org.security.PassHash;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SecurityBeansConfig {
    @Bean
    public PassHash passHash() {
        return new PassHash();
    }

    @Bean
    public ServiceContainer serviceContainer() {
        return new ServiceContainer();
    }
}