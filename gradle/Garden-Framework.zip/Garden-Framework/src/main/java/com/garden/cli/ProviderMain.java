package com.garden.cli;

import com.garden.Application;
import com.garden.loader.ProviderExecute;
import org.springframework.boot.WebApplicationType;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.ConfigurableApplicationContext;

public final class ProviderMain {
    public static void main(String[] args) {
        try (ConfigurableApplicationContext context =
                     new SpringApplicationBuilder(Application.class)
                             .web(WebApplicationType.NONE)
                             .run()) {

            ProviderExecute provider =
                    context.getBean(ProviderExecute.class);

            String command = args.length == 0
                    ? "none"
                    : String.join(" ", args);

            provider.execute(command);
        }
    }
}