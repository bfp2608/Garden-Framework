package com.garden.app.repository;

import com.garden.app.models.User;
import com.glass.data.EntityDao;
import org.springframework.stereotype.Repository;

@Repository
public class UserDao extends EntityDao<User,Long>{
    public UserDao(){
        super(User.class);
    }
}