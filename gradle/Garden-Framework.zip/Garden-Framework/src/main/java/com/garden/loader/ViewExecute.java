package com.garden.loader;

import com.garden.annotations.View;
import com.garden.views.GardenViewProvider;
import com.garden.views.ViewConvert;
import frames.Frame;
import org.springframework.stereotype.Component;
import javax.swing.SwingUtilities;
import java.util.List;

@Component
public final class ViewExecute {
    private final List<GardenViewProvider<?>> providers;

    public ViewExecute(List<GardenViewProvider<?>> providers) {
        this.providers = providers;
    }

    public void execute() {
        for (GardenViewProvider<?> provider : providers) {
            Object view = provider.createView();
            View annotation = view.getClass().getAnnotation(View.class);
            if (annotation == null) {
                throw new IllegalArgumentException(
                        "View must implement @View"
                );
            }
            if (!(view instanceof Frame frame)) {
                throw new IllegalArgumentException(
                        "Unsupported view type: " + view.getClass().getName()
                );
            }
            if (annotation.html()) {
                ViewConvert.toHtml(frame);
            } else if (annotation.main()) {
                SwingUtilities.invokeLater(frame::show);
            }
        }
    }
}