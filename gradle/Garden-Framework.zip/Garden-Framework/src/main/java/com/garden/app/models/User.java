package com.garden.app.models;

import com.garden.utils.AuthModel;
import com.glass.annotations.Column;
import com.glass.annotations.Entity;
import com.glass.annotations.PrimaryKey;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;

@EqualsAndHashCode(callSuper = true)
@Entity(tableName = "users")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class User extends AuthModel{
    @PrimaryKey(name = "user_id")
    private long id;

    @Column(name = "name",unique = true)
    private String name;

    @Column(name = "password",nullable = false)
    private String password;

    @Column(name = "email",nullable = false,unique = true)
    private String email;

    @Column(name = "email_verify_at")
    private LocalDateTime emailVerifyAt;
}