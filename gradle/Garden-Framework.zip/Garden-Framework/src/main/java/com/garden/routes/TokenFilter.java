package com.garden.routes;

import com.gum.org.auth.Session;
import com.gum.org.auth.SessionConfig;
import com.gum.org.auth.SessionContext;
import com.gum.org.auth.SessionManager;
import com.gum.org.token.Token;

import database.utils.Types;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.List;

public final class TokenFilter extends OncePerRequestFilter {
    private final Token token;
    private final SessionManager sessionManager;

    public TokenFilter(Token token) {
        this.token = token;
        this.sessionManager = SessionConfig.getManager();
    }

    @Override
    protected void doFilterInternal(
            HttpServletRequest request,
            HttpServletResponse response,
            FilterChain filterChain
    ) throws ServletException, IOException {
        String authorization = request.getHeader("Authorization");
        if (authorization == null || !authorization.startsWith("Bearer ")) {
            filterChain.doFilter(request, response);
            return;
        }

        try {
            String jwt = authorization.substring(7);
            if (!token.isValid(jwt)) {
                response.sendError(
                        HttpServletResponse.SC_UNAUTHORIZED,
                        "Token inválido o expirado"
                );
                return;
            }
            String subject = token.extractSubject(jwt);
            String sessionId = Types.toString(token.extractClaim(jwt, "session_id"));
            if (sessionId == null || sessionId.isBlank()) {
                response.sendError(
                        HttpServletResponse.SC_UNAUTHORIZED,
                        "El token no tiene una sesión asociada"
                );
                return;
            }

            Session session = sessionManager.find(sessionId)
                    .orElse(null);
            if (session == null
                    || !session.isAuthenticated()
                    || !subject.equals(String.valueOf(session.getUserId()))) {
                response.sendError(
                        HttpServletResponse.SC_UNAUTHORIZED,
                        "Sesión inválida o expirada"
                );
                return;
            }
            SessionContext.set(session);
            UsernamePasswordAuthenticationToken authentication =
                    new UsernamePasswordAuthenticationToken(
                            session.getUserId(),
                            null,
                            List.of()
                    );

            SecurityContextHolder.getContext()
                    .setAuthentication(authentication);
            filterChain.doFilter(request, response);
        } catch (RuntimeException e) {
            SecurityContextHolder.clearContext();
            response.sendError(
                    HttpServletResponse.SC_UNAUTHORIZED,
                    "No se pudo autenticar la solicitud"
            );
        } finally {
            SessionContext.clear();
        }
    }
}