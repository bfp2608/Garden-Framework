package com.garden.config;

import com.gum.org.token.Token;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class TokenConfig {
    @Bean
    public Token token(
            @Value("${garden.token.secret-key}") String secretKey
    ) {
        return new Token(secretKey);
    }
}