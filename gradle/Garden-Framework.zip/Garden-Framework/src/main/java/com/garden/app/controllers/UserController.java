package com.garden.app.controllers;

import com.garden.utils.controller.Controller;
import com.garden.views.ViewObject;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@org.springframework.stereotype.Controller
@RequestMapping("/api")
public class UserController extends Controller {
    @GetMapping("/home")
    @ResponseBody
    public String index() {
        return ViewObject.viewHtml("index");
    }
}