package com.garden.loader;

import com.glass.database.connection.ConnectionPool;
import com.glass.database.loggers.SqlLogger;
import com.glass.migrations.Migration;
import org.springframework.stereotype.Component;
import java.sql.*;
import java.util.*;

@Component
public final class MigrationExecute{
    private final List<Migration> migrations;

    public MigrationExecute(List<Migration> migrations) {
        this.migrations = new ArrayList<>(migrations);
        SqlLogger.log("Migration execute initialized");
    }

    public void execute(String commandLine) {
        if (commandLine == null || commandLine.isBlank()) {
            return;
        }
        String[] command = commandLine.trim().split("\\s+", 2);
        switch (command[0].toLowerCase(Locale.ROOT)) {
            case "run" -> run();
            case "rollback" -> {
                if (command.length > 1) {
                    try {
                        rollback(Integer.parseInt(command[1].trim()));
                    } catch (NumberFormatException e) {
                        throw new IllegalArgumentException(
                                "La cantidad de migraciones debe ser un número entero",
                                e
                        );
                    }
                } else {
                    rollback();
                }
            }

            case "reset" -> reset();

            case "refresh" -> refresh();

            case "none" -> SqlLogger.log(
                    "Migration execution skipped"
            );

            default -> throw new IllegalArgumentException(
                    "Comando no reconocido: " + command[0]
            );
        }
    }

    public void run() {
        prepare();

        for (Migration migration : migrations) {
            executeMigration(migration);
        }
    }

    public void rollback() {
        rollback(1);
    }

    public void rollback(int steps) {
        if (steps <= 0) {
            throw new IllegalArgumentException(
                    "La cantidad de migraciones debe ser mayor que cero"
            );
        }

        prepare();
        rollbackMigrations(steps);
    }

    public void reset() {
        prepare();
        rollbackMigrations(Integer.MAX_VALUE);
    }

    public void refresh() {
        reset();
        run();
    }

    private void prepare() {
        validateMigrations();
        migrations.sort(
                Comparator.comparingLong(Migration::version)
        );
        try {
            createHistoryTable();
        } catch (SQLException e) {
            throw new IllegalStateException(
                    "No se pudo preparar el historial de migraciones",
                    e
            );
        }
    }

    private void validateMigrations() {
        Set<Long> versions = new HashSet<>();

        for (Migration migration : migrations) {
            long version = migration.version();

            if (version <= 0) {
                throw new IllegalStateException(
                        "La versión de una migración debe ser mayor que cero: "
                                + migration.getClass().getSimpleName()
                );
            }

            if (!versions.add(version)) {
                throw new IllegalStateException(
                        "Versión de migración duplicada: " + version
                );
            }

            if (migration.description() == null
                    || migration.description().isBlank()) {
                throw new IllegalStateException(
                        "La descripción de la migración no puede estar vacía: "
                                + migration.getClass().getSimpleName()
                );
            }
        }
    }

    private void createHistoryTable() throws SQLException {
        Connection connection = ConnectionPool.get();
        DatabaseMetaData metadata = connection.getMetaData();
        String database = metadata.getDatabaseProductName()
                .toLowerCase(Locale.ROOT);
        String tableName = "glass_migrations";
        String catalog = connection.getCatalog();
        String schema = connection.getSchema();
        String metadataTableName = database.contains("oracle")
                ? tableName.toUpperCase(Locale.ROOT)
                : tableName;
        try (ResultSet tables = metadata.getTables(
                catalog,
                schema,
                metadataTableName,
                new String[]{"TABLE"}
        )) {
            if (tables.next()) {
                return;
            }
        }

        String versionType;
        String descriptionType;
        String executedAtType;

        switch (database) {
            case String db when db.contains("mysql") -> {
                versionType = "BIGINT";
                descriptionType = "VARCHAR(500)";
                executedAtType = "TIMESTAMP";
            }

            case String db when db.contains("postgresql") -> {
                versionType = "BIGINT";
                descriptionType = "VARCHAR(500)";
                executedAtType = "TIMESTAMP WITH TIME ZONE";
            }

            case String db when db.contains("microsoft sql server") -> {
                versionType = "BIGINT";
                descriptionType = "VARCHAR(500)";
                executedAtType = "DATETIME2(6)";
            }

            case String db when db.contains("oracle") -> {
                versionType = "NUMBER(19,0)";
                descriptionType = "VARCHAR2(500)";
                executedAtType = "TIMESTAMP WITH TIME ZONE";
            }

            default -> throw new UnsupportedOperationException(
                    "Motor de base de datos no soportado: "
                            + metadata.getDatabaseProductName()
            );
        }

        String sql = """
                CREATE TABLE glass_migrations (
                    version %s PRIMARY KEY,
                    migration VARCHAR(255) NOT NULL,
                    description %s NOT NULL,
                    executed_at %s NOT NULL DEFAULT CURRENT_TIMESTAMP
                )
                """.formatted(
                versionType,
                descriptionType,
                executedAtType
        );

        try (Statement statement = connection.createStatement()) {
            SqlLogger.log(sql);
            statement.execute(sql);
        }
    }

    private void executeMigration(Migration migration) {
        long version = migration.version();

        if (alreadyExecuted(version)) {
            return;
        }

        String name = migration.getClass().getSimpleName();

        try {
            SqlLogger.log(
                    "Ejecutando migración V"
                            + version + ": " + migration.description()
            );
            migration.up();
            registerMigration(migration);

            SqlLogger.log(
                    "Migración ejecutada correctamente: " + name
            );

        } catch (Exception e) {
            throw new IllegalStateException(
                    "Error ejecutando migración V"
                            + version + ": " + name,
                    e
            );
        }
    }

    private void rollbackMigrations(int steps) {
        List<Long> versions = getExecutedVersions();

        int count = Math.min(steps, versions.size());

        for (int i = 0; i < count; i++) {
            long version = versions.get(i);

            Migration migration = findMigration(version);

            if (migration == null) {
                throw new IllegalStateException(
                        "No se encontró la migración correspondiente "
                                + "a la versión: " + version
                );
            }

            String name = migration.getClass().getSimpleName();

            try {
                SqlLogger.log(
                        "Revirtiendo migración V"
                                + version + ": " + migration.description()
                );

                migration.down();

                removeMigration(version);

                SqlLogger.log(
                        "Migración revertida correctamente: " + name
                );

            } catch (Exception e) {
                throw new IllegalStateException(
                        "Error revirtiendo migración V"
                                + version + ": " + name,
                        e
                );
            }
        }
    }

    private List<Long> getExecutedVersions() {
        String sql = """
                SELECT version
                FROM glass_migrations
                ORDER BY version DESC
                """;

        List<Long> versions = new ArrayList<>();

        try (
                PreparedStatement statement =
                        SqlLogger.prepareStatement(
                                ConnectionPool.get(),
                                sql
                        );

                ResultSet result = statement.executeQuery()
        ) {
            while (result.next()) {
                versions.add(result.getLong("version"));
            }

        } catch (Exception e) {
            throw new IllegalStateException(
                    "No se pudo consultar el historial de migraciones",
                    e
            );
        }

        return versions;
    }

    private Migration findMigration(long version) {
        return migrations.stream()
                .filter(migration -> migration.version() == version)
                .findFirst()
                .orElse(null);
    }

    private boolean alreadyExecuted(long version) {
        String sql = """
                SELECT 1
                FROM glass_migrations
                WHERE version = ?
                """;

        try (
                PreparedStatement statement =
                        SqlLogger.prepareStatement(
                                ConnectionPool.get(),
                                sql
                        )
        ) {
            statement.setLong(1, version);

            try (ResultSet result = statement.executeQuery()) {
                return result.next();
            }

        } catch (Exception e) {
            throw new IllegalStateException(
                    "No se pudo consultar el historial de migraciones",
                    e
            );
        }
    }

    private void registerMigration(Migration migration) {
        String sql = """
                INSERT INTO glass_migrations (
                    version,
                    migration,
                    description
                ) VALUES (?, ?, ?)
                """;

        try (
                PreparedStatement statement =
                        SqlLogger.prepareStatement(
                                ConnectionPool.get(),
                                sql
                        )
        ) {
            statement.setLong(1, migration.version());

            statement.setString(
                    2,
                    migration.getClass().getSimpleName()
            );

            statement.setString(3, migration.description());

            statement.executeUpdate();

        } catch (Exception e) {
            throw new IllegalStateException(
                    "No se pudo registrar la migración: "
                            + migration.getClass().getSimpleName(),
                    e
            );
        }
    }

    private void removeMigration(long version) {
        String sql = """
                DELETE FROM glass_migrations
                WHERE version = ?
                """;

        try (
                PreparedStatement statement =
                        SqlLogger.prepareStatement(
                                ConnectionPool.get(),
                                sql
                        )
        ) {
            statement.setLong(1, version);
            statement.executeUpdate();

        } catch (Exception e) {
            throw new IllegalStateException(
                    "No se pudo eliminar la migración del historial: "
                            + version,
                    e
            );
        }
    }
}